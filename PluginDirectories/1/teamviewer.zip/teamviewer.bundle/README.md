# TeamViewer Plugin for [Flashlight](http://flashlight.nateparrott.com/)
To connect to a teamviewer session, use `teamviewer id, password`. e.g. `teamviewer 330 161 409, 123123`

![ScreenShot](https://raw.github.com/marcbachmann/flashlight-teamviewer/master/Screenshot.jpg)

